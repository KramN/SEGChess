/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.18.0.3190 modeling language!*/


import java.util.*;

// line 53 "model.ump"
public class PieceType
{
  @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
  public @interface umplesourcefile{int[] line();String[] file();int[] javaline();int[] length();}

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //PieceType Attributes
  private String description;

  //PieceType Associations
  private List<SpecificPiece> specificPieces;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public PieceType(String aDescription)
  {
    description = aDescription;
    specificPieces = new ArrayList<SpecificPiece>();
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setDescription(String aDescription)
  {
    boolean wasSet = false;
    description = aDescription;
    wasSet = true;
    return wasSet;
  }

  public String getDescription()
  {
    return description;
  }

  public SpecificPiece getSpecificPiece(int index)
  {
    SpecificPiece aSpecificPiece = specificPieces.get(index);
    return aSpecificPiece;
  }

  public List<SpecificPiece> getSpecificPieces()
  {
    List<SpecificPiece> newSpecificPieces = Collections.unmodifiableList(specificPieces);
    return newSpecificPieces;
  }

  public int numberOfSpecificPieces()
  {
    int number = specificPieces.size();
    return number;
  }

  public boolean hasSpecificPieces()
  {
    boolean has = specificPieces.size() > 0;
    return has;
  }

  public int indexOfSpecificPiece(SpecificPiece aSpecificPiece)
  {
    int index = specificPieces.indexOf(aSpecificPiece);
    return index;
  }

  public static int minimumNumberOfSpecificPieces()
  {
    return 0;
  }

  public SpecificPiece addSpecificPiece(Player aPlayer, Board aBoard)
  {
    return new SpecificPiece(aPlayer, this, aBoard);
  }

  public boolean addSpecificPiece(SpecificPiece aSpecificPiece)
  {
    boolean wasAdded = false;
    if (specificPieces.contains(aSpecificPiece)) { return false; }
    PieceType existingPieceType = aSpecificPiece.getPieceType();
    boolean isNewPieceType = existingPieceType != null && !this.equals(existingPieceType);
    if (isNewPieceType)
    {
      aSpecificPiece.setPieceType(this);
    }
    else
    {
      specificPieces.add(aSpecificPiece);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeSpecificPiece(SpecificPiece aSpecificPiece)
  {
    boolean wasRemoved = false;
    //Unable to remove aSpecificPiece, as it must always have a pieceType
    if (!this.equals(aSpecificPiece.getPieceType()))
    {
      specificPieces.remove(aSpecificPiece);
      wasRemoved = true;
    }
    return wasRemoved;
  }

  public boolean addSpecificPieceAt(SpecificPiece aSpecificPiece, int index)
  {  
    boolean wasAdded = false;
    if(addSpecificPiece(aSpecificPiece))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfSpecificPieces()) { index = numberOfSpecificPieces() - 1; }
      specificPieces.remove(aSpecificPiece);
      specificPieces.add(index, aSpecificPiece);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveSpecificPieceAt(SpecificPiece aSpecificPiece, int index)
  {
    boolean wasAdded = false;
    if(specificPieces.contains(aSpecificPiece))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfSpecificPieces()) { index = numberOfSpecificPieces() - 1; }
      specificPieces.remove(aSpecificPiece);
      specificPieces.add(index, aSpecificPiece);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addSpecificPieceAt(aSpecificPiece, index);
    }
    return wasAdded;
  }

  public void delete()
  {
    for(int i=specificPieces.size(); i > 0; i--)
    {
      SpecificPiece aSpecificPiece = specificPieces.get(i - 1);
      aSpecificPiece.delete();
    }
  }


  public String toString()
  {
	  String outputString = "";
    return super.toString() + "["+
            "description" + ":" + getDescription()+ "]"
     + outputString;
  }
}