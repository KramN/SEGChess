/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.18.0.3190 modeling language!*/


import java.util.*;

// line 47 "model.ump"
public class Turn
{
  @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
  public @interface umplesourcefile{int[] line();String[] file();int[] javaline();int[] length();}

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Turn Attributes
  private int turnNumber;

  //Turn Associations
  private Player player;
  private List<SpecificPiece> specificPieces;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Turn(int aTurnNumber, Player aPlayer)
  {
    turnNumber = aTurnNumber;
    boolean didAddPlayer = setPlayer(aPlayer);
    if (!didAddPlayer)
    {
      throw new RuntimeException("Unable to create turn due to player");
    }
    specificPieces = new ArrayList<SpecificPiece>();
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setTurnNumber(int aTurnNumber)
  {
    boolean wasSet = false;
    turnNumber = aTurnNumber;
    wasSet = true;
    return wasSet;
  }

  public int getTurnNumber()
  {
    return turnNumber;
  }

  public Player getPlayer()
  {
    return player;
  }

  public SpecificPiece getSpecificPiece(int index)
  {
    SpecificPiece aSpecificPiece = specificPieces.get(index);
    return aSpecificPiece;
  }

  public List<SpecificPiece> getSpecificPieces()
  {
    List<SpecificPiece> newSpecificPieces = Collections.unmodifiableList(specificPieces);
    return newSpecificPieces;
  }

  public int numberOfSpecificPieces()
  {
    int number = specificPieces.size();
    return number;
  }

  public boolean hasSpecificPieces()
  {
    boolean has = specificPieces.size() > 0;
    return has;
  }

  public int indexOfSpecificPiece(SpecificPiece aSpecificPiece)
  {
    int index = specificPieces.indexOf(aSpecificPiece);
    return index;
  }

  public boolean setPlayer(Player aPlayer)
  {
    boolean wasSet = false;
    if (aPlayer == null)
    {
      return wasSet;
    }

    Player existingPlayer = player;
    player = aPlayer;
    if (existingPlayer != null && !existingPlayer.equals(aPlayer))
    {
      existingPlayer.removeTurn(this);
    }
    player.addTurn(this);
    wasSet = true;
    return wasSet;
  }

  public static int minimumNumberOfSpecificPieces()
  {
    return 0;
  }

  public boolean addSpecificPiece(SpecificPiece aSpecificPiece)
  {
    boolean wasAdded = false;
    if (specificPieces.contains(aSpecificPiece)) { return false; }
    specificPieces.add(aSpecificPiece);
    if (aSpecificPiece.indexOfTurn(this) != -1)
    {
      wasAdded = true;
    }
    else
    {
      wasAdded = aSpecificPiece.addTurn(this);
      if (!wasAdded)
      {
        specificPieces.remove(aSpecificPiece);
      }
    }
    return wasAdded;
  }

  public boolean removeSpecificPiece(SpecificPiece aSpecificPiece)
  {
    boolean wasRemoved = false;
    if (!specificPieces.contains(aSpecificPiece))
    {
      return wasRemoved;
    }

    int oldIndex = specificPieces.indexOf(aSpecificPiece);
    specificPieces.remove(oldIndex);
    if (aSpecificPiece.indexOfTurn(this) == -1)
    {
      wasRemoved = true;
    }
    else
    {
      wasRemoved = aSpecificPiece.removeTurn(this);
      if (!wasRemoved)
      {
        specificPieces.add(oldIndex,aSpecificPiece);
      }
    }
    return wasRemoved;
  }

  public boolean addSpecificPieceAt(SpecificPiece aSpecificPiece, int index)
  {  
    boolean wasAdded = false;
    if(addSpecificPiece(aSpecificPiece))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfSpecificPieces()) { index = numberOfSpecificPieces() - 1; }
      specificPieces.remove(aSpecificPiece);
      specificPieces.add(index, aSpecificPiece);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveSpecificPieceAt(SpecificPiece aSpecificPiece, int index)
  {
    boolean wasAdded = false;
    if(specificPieces.contains(aSpecificPiece))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfSpecificPieces()) { index = numberOfSpecificPieces() - 1; }
      specificPieces.remove(aSpecificPiece);
      specificPieces.add(index, aSpecificPiece);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addSpecificPieceAt(aSpecificPiece, index);
    }
    return wasAdded;
  }

  public void delete()
  {
    Player placeholderPlayer = player;
    this.player = null;
    placeholderPlayer.removeTurn(this);
    ArrayList<SpecificPiece> copyOfSpecificPieces = new ArrayList<SpecificPiece>(specificPieces);
    specificPieces.clear();
    for(SpecificPiece aSpecificPiece : copyOfSpecificPieces)
    {
      aSpecificPiece.removeTurn(this);
    }
  }


  public String toString()
  {
	  String outputString = "";
    return super.toString() + "["+
            "turnNumber" + ":" + getTurnNumber()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "player = "+(getPlayer()!=null?Integer.toHexString(System.identityHashCode(getPlayer())):"null")
     + outputString;
  }
}