/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.18.0.3190 modeling language!*/


import java.util.*;

// line 1 "model.ump"
public class Board
{
  @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
  public @interface umplesourcefile{int[] line();String[] file();int[] javaline();int[] length();}

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Board Associations
  private List<Square> squares;
  private List<SpecificPiece> specificPieces;
  private Game game;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Board(Game aGame)
  {
    squares = new ArrayList<Square>();
    specificPieces = new ArrayList<SpecificPiece>();
    boolean didAddGame = setGame(aGame);
    if (!didAddGame)
    {
      throw new RuntimeException("Unable to create board due to game");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------

  public Square getSquare(int index)
  {
    Square aSquare = squares.get(index);
    return aSquare;
  }

  public List<Square> getSquares()
  {
    List<Square> newSquares = Collections.unmodifiableList(squares);
    return newSquares;
  }

  public int numberOfSquares()
  {
    int number = squares.size();
    return number;
  }

  public boolean hasSquares()
  {
    boolean has = squares.size() > 0;
    return has;
  }

  public int indexOfSquare(Square aSquare)
  {
    int index = squares.indexOf(aSquare);
    return index;
  }

  public SpecificPiece getSpecificPiece(int index)
  {
    SpecificPiece aSpecificPiece = specificPieces.get(index);
    return aSpecificPiece;
  }

  public List<SpecificPiece> getSpecificPieces()
  {
    List<SpecificPiece> newSpecificPieces = Collections.unmodifiableList(specificPieces);
    return newSpecificPieces;
  }

  public int numberOfSpecificPieces()
  {
    int number = specificPieces.size();
    return number;
  }

  public boolean hasSpecificPieces()
  {
    boolean has = specificPieces.size() > 0;
    return has;
  }

  public int indexOfSpecificPiece(SpecificPiece aSpecificPiece)
  {
    int index = specificPieces.indexOf(aSpecificPiece);
    return index;
  }

  public Game getGame()
  {
    return game;
  }

  public static int minimumNumberOfSquares()
  {
    return 0;
  }

  public Square addSquare(int aXCoord, int aYCoord)
  {
    return new Square(aXCoord, aYCoord, this);
  }

  public boolean addSquare(Square aSquare)
  {
    boolean wasAdded = false;
    if (squares.contains(aSquare)) { return false; }
    Board existingBoard = aSquare.getBoard();
    boolean isNewBoard = existingBoard != null && !this.equals(existingBoard);
    if (isNewBoard)
    {
      aSquare.setBoard(this);
    }
    else
    {
      squares.add(aSquare);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeSquare(Square aSquare)
  {
    boolean wasRemoved = false;
    //Unable to remove aSquare, as it must always have a board
    if (!this.equals(aSquare.getBoard()))
    {
      squares.remove(aSquare);
      wasRemoved = true;
    }
    return wasRemoved;
  }

  public boolean addSquareAt(Square aSquare, int index)
  {  
    boolean wasAdded = false;
    if(addSquare(aSquare))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfSquares()) { index = numberOfSquares() - 1; }
      squares.remove(aSquare);
      squares.add(index, aSquare);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveSquareAt(Square aSquare, int index)
  {
    boolean wasAdded = false;
    if(squares.contains(aSquare))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfSquares()) { index = numberOfSquares() - 1; }
      squares.remove(aSquare);
      squares.add(index, aSquare);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addSquareAt(aSquare, index);
    }
    return wasAdded;
  }

  public static int minimumNumberOfSpecificPieces()
  {
    return 0;
  }

  public SpecificPiece addSpecificPiece(Player aPlayer, PieceType aPieceType)
  {
    return new SpecificPiece(aPlayer, aPieceType, this);
  }

  public boolean addSpecificPiece(SpecificPiece aSpecificPiece)
  {
    boolean wasAdded = false;
    if (specificPieces.contains(aSpecificPiece)) { return false; }
    Board existingBoard = aSpecificPiece.getBoard();
    boolean isNewBoard = existingBoard != null && !this.equals(existingBoard);
    if (isNewBoard)
    {
      aSpecificPiece.setBoard(this);
    }
    else
    {
      specificPieces.add(aSpecificPiece);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeSpecificPiece(SpecificPiece aSpecificPiece)
  {
    boolean wasRemoved = false;
    //Unable to remove aSpecificPiece, as it must always have a board
    if (!this.equals(aSpecificPiece.getBoard()))
    {
      specificPieces.remove(aSpecificPiece);
      wasRemoved = true;
    }
    return wasRemoved;
  }

  public boolean addSpecificPieceAt(SpecificPiece aSpecificPiece, int index)
  {  
    boolean wasAdded = false;
    if(addSpecificPiece(aSpecificPiece))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfSpecificPieces()) { index = numberOfSpecificPieces() - 1; }
      specificPieces.remove(aSpecificPiece);
      specificPieces.add(index, aSpecificPiece);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveSpecificPieceAt(SpecificPiece aSpecificPiece, int index)
  {
    boolean wasAdded = false;
    if(specificPieces.contains(aSpecificPiece))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfSpecificPieces()) { index = numberOfSpecificPieces() - 1; }
      specificPieces.remove(aSpecificPiece);
      specificPieces.add(index, aSpecificPiece);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addSpecificPieceAt(aSpecificPiece, index);
    }
    return wasAdded;
  }

  public boolean setGame(Game aNewGame)
  {
    boolean wasSet = false;
    if (aNewGame == null)
    {
      //Unable to setGame to null, as board must always be associated to a game
      return wasSet;
    }
    
    Board existingBoard = aNewGame.getBoard();
    if (existingBoard != null && !equals(existingBoard))
    {
      //Unable to setGame, the current game already has a board, which would be orphaned if it were re-assigned
      return wasSet;
    }
    
    Game anOldGame = game;
    game = aNewGame;
    game.setBoard(this);

    if (anOldGame != null)
    {
      anOldGame.setBoard(null);
    }
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    for(int i=squares.size(); i > 0; i--)
    {
      Square aSquare = squares.get(i - 1);
      aSquare.delete();
    }
    for(int i=specificPieces.size(); i > 0; i--)
    {
      SpecificPiece aSpecificPiece = specificPieces.get(i - 1);
      aSpecificPiece.delete();
    }
    Game existingGame = game;
    game = null;
    if (existingGame != null)
    {
      existingGame.setBoard(null);
    }
  }

}