/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.18.0.3190 modeling language!*/


import java.util.*;

// line 42 "model.ump"
public class Player
{
  @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
  public @interface umplesourcefile{int[] line();String[] file();int[] javaline();int[] length();}

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Player Attributes
  private String name;
  private String colour;

  //Player Associations
  private List<SpecificPiece> specificPieces;
  private List<Turn> turns;
  private List<Game> games;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Player(String aName, String aColour)
  {
    name = aName;
    colour = aColour;
    specificPieces = new ArrayList<SpecificPiece>();
    turns = new ArrayList<Turn>();
    games = new ArrayList<Game>();
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setName(String aName)
  {
    boolean wasSet = false;
    name = aName;
    wasSet = true;
    return wasSet;
  }

  public boolean setColour(String aColour)
  {
    boolean wasSet = false;
    colour = aColour;
    wasSet = true;
    return wasSet;
  }

  public String getName()
  {
    return name;
  }

  public String getColour()
  {
    return colour;
  }

  public SpecificPiece getSpecificPiece(int index)
  {
    SpecificPiece aSpecificPiece = specificPieces.get(index);
    return aSpecificPiece;
  }

  public List<SpecificPiece> getSpecificPieces()
  {
    List<SpecificPiece> newSpecificPieces = Collections.unmodifiableList(specificPieces);
    return newSpecificPieces;
  }

  public int numberOfSpecificPieces()
  {
    int number = specificPieces.size();
    return number;
  }

  public boolean hasSpecificPieces()
  {
    boolean has = specificPieces.size() > 0;
    return has;
  }

  public int indexOfSpecificPiece(SpecificPiece aSpecificPiece)
  {
    int index = specificPieces.indexOf(aSpecificPiece);
    return index;
  }

  public Turn getTurn(int index)
  {
    Turn aTurn = turns.get(index);
    return aTurn;
  }

  public List<Turn> getTurns()
  {
    List<Turn> newTurns = Collections.unmodifiableList(turns);
    return newTurns;
  }

  public int numberOfTurns()
  {
    int number = turns.size();
    return number;
  }

  public boolean hasTurns()
  {
    boolean has = turns.size() > 0;
    return has;
  }

  public int indexOfTurn(Turn aTurn)
  {
    int index = turns.indexOf(aTurn);
    return index;
  }

  public Game getGame(int index)
  {
    Game aGame = games.get(index);
    return aGame;
  }

  public List<Game> getGames()
  {
    List<Game> newGames = Collections.unmodifiableList(games);
    return newGames;
  }

  public int numberOfGames()
  {
    int number = games.size();
    return number;
  }

  public boolean hasGames()
  {
    boolean has = games.size() > 0;
    return has;
  }

  public int indexOfGame(Game aGame)
  {
    int index = games.indexOf(aGame);
    return index;
  }

  public static int minimumNumberOfSpecificPieces()
  {
    return 0;
  }

  public SpecificPiece addSpecificPiece(PieceType aPieceType, Board aBoard)
  {
    return new SpecificPiece(this, aPieceType, aBoard);
  }

  public boolean addSpecificPiece(SpecificPiece aSpecificPiece)
  {
    boolean wasAdded = false;
    if (specificPieces.contains(aSpecificPiece)) { return false; }
    Player existingPlayer = aSpecificPiece.getPlayer();
    boolean isNewPlayer = existingPlayer != null && !this.equals(existingPlayer);
    if (isNewPlayer)
    {
      aSpecificPiece.setPlayer(this);
    }
    else
    {
      specificPieces.add(aSpecificPiece);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeSpecificPiece(SpecificPiece aSpecificPiece)
  {
    boolean wasRemoved = false;
    //Unable to remove aSpecificPiece, as it must always have a player
    if (!this.equals(aSpecificPiece.getPlayer()))
    {
      specificPieces.remove(aSpecificPiece);
      wasRemoved = true;
    }
    return wasRemoved;
  }

  public boolean addSpecificPieceAt(SpecificPiece aSpecificPiece, int index)
  {  
    boolean wasAdded = false;
    if(addSpecificPiece(aSpecificPiece))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfSpecificPieces()) { index = numberOfSpecificPieces() - 1; }
      specificPieces.remove(aSpecificPiece);
      specificPieces.add(index, aSpecificPiece);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveSpecificPieceAt(SpecificPiece aSpecificPiece, int index)
  {
    boolean wasAdded = false;
    if(specificPieces.contains(aSpecificPiece))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfSpecificPieces()) { index = numberOfSpecificPieces() - 1; }
      specificPieces.remove(aSpecificPiece);
      specificPieces.add(index, aSpecificPiece);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addSpecificPieceAt(aSpecificPiece, index);
    }
    return wasAdded;
  }

  public static int minimumNumberOfTurns()
  {
    return 0;
  }

  public Turn addTurn(int aTurnNumber)
  {
    return new Turn(aTurnNumber, this);
  }

  public boolean addTurn(Turn aTurn)
  {
    boolean wasAdded = false;
    if (turns.contains(aTurn)) { return false; }
    Player existingPlayer = aTurn.getPlayer();
    boolean isNewPlayer = existingPlayer != null && !this.equals(existingPlayer);
    if (isNewPlayer)
    {
      aTurn.setPlayer(this);
    }
    else
    {
      turns.add(aTurn);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeTurn(Turn aTurn)
  {
    boolean wasRemoved = false;
    //Unable to remove aTurn, as it must always have a player
    if (!this.equals(aTurn.getPlayer()))
    {
      turns.remove(aTurn);
      wasRemoved = true;
    }
    return wasRemoved;
  }

  public boolean addTurnAt(Turn aTurn, int index)
  {  
    boolean wasAdded = false;
    if(addTurn(aTurn))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfTurns()) { index = numberOfTurns() - 1; }
      turns.remove(aTurn);
      turns.add(index, aTurn);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveTurnAt(Turn aTurn, int index)
  {
    boolean wasAdded = false;
    if(turns.contains(aTurn))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfTurns()) { index = numberOfTurns() - 1; }
      turns.remove(aTurn);
      turns.add(index, aTurn);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addTurnAt(aTurn, index);
    }
    return wasAdded;
  }

  public static int minimumNumberOfGames()
  {
    return 0;
  }

  public boolean addGame(Game aGame)
  {
    boolean wasAdded = false;
    if (games.contains(aGame)) { return false; }
    games.add(aGame);
    if (aGame.indexOfPlayer(this) != -1)
    {
      wasAdded = true;
    }
    else
    {
      wasAdded = aGame.addPlayer(this);
      if (!wasAdded)
      {
        games.remove(aGame);
      }
    }
    return wasAdded;
  }

  public boolean removeGame(Game aGame)
  {
    boolean wasRemoved = false;
    if (!games.contains(aGame))
    {
      return wasRemoved;
    }

    int oldIndex = games.indexOf(aGame);
    games.remove(oldIndex);
    if (aGame.indexOfPlayer(this) == -1)
    {
      wasRemoved = true;
    }
    else
    {
      wasRemoved = aGame.removePlayer(this);
      if (!wasRemoved)
      {
        games.add(oldIndex,aGame);
      }
    }
    return wasRemoved;
  }

  public boolean addGameAt(Game aGame, int index)
  {  
    boolean wasAdded = false;
    if(addGame(aGame))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfGames()) { index = numberOfGames() - 1; }
      games.remove(aGame);
      games.add(index, aGame);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveGameAt(Game aGame, int index)
  {
    boolean wasAdded = false;
    if(games.contains(aGame))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfGames()) { index = numberOfGames() - 1; }
      games.remove(aGame);
      games.add(index, aGame);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addGameAt(aGame, index);
    }
    return wasAdded;
  }

  public void delete()
  {
    for(int i=specificPieces.size(); i > 0; i--)
    {
      SpecificPiece aSpecificPiece = specificPieces.get(i - 1);
      aSpecificPiece.delete();
    }
    for(int i=turns.size(); i > 0; i--)
    {
      Turn aTurn = turns.get(i - 1);
      aTurn.delete();
    }
    ArrayList<Game> copyOfGames = new ArrayList<Game>(games);
    games.clear();
    for(Game aGame : copyOfGames)
    {
      aGame.removePlayer(this);
    }
  }


  public String toString()
  {
	  String outputString = "";
    return super.toString() + "["+
            "name" + ":" + getName()+ "," +
            "colour" + ":" + getColour()+ "]"
     + outputString;
  }
}