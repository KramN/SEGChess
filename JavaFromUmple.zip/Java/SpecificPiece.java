/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.18.0.3190 modeling language!*/


import java.util.*;

// line 13 "model.ump"
public class SpecificPiece
{
  @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
  public @interface umplesourcefile{int[] line();String[] file();int[] javaline();int[] length();}

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //SpecificPiece Associations
  private Player player;
  private PieceType pieceType;
  private Board board;
  private Square square;
  private List<Turn> turns;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public SpecificPiece(Player aPlayer, PieceType aPieceType, Board aBoard)
  {
    boolean didAddPlayer = setPlayer(aPlayer);
    if (!didAddPlayer)
    {
      throw new RuntimeException("Unable to create specificPiece due to player");
    }
    boolean didAddPieceType = setPieceType(aPieceType);
    if (!didAddPieceType)
    {
      throw new RuntimeException("Unable to create specificPiece due to pieceType");
    }
    boolean didAddBoard = setBoard(aBoard);
    if (!didAddBoard)
    {
      throw new RuntimeException("Unable to create specificPiece due to board");
    }
    turns = new ArrayList<Turn>();
  }

  //------------------------
  // INTERFACE
  //------------------------

  public Player getPlayer()
  {
    return player;
  }

  public PieceType getPieceType()
  {
    return pieceType;
  }

  public Board getBoard()
  {
    return board;
  }

  public Square getSquare()
  {
    return square;
  }

  public Turn getTurn(int index)
  {
    Turn aTurn = turns.get(index);
    return aTurn;
  }

  public List<Turn> getTurns()
  {
    List<Turn> newTurns = Collections.unmodifiableList(turns);
    return newTurns;
  }

  public int numberOfTurns()
  {
    int number = turns.size();
    return number;
  }

  public boolean hasTurns()
  {
    boolean has = turns.size() > 0;
    return has;
  }

  public int indexOfTurn(Turn aTurn)
  {
    int index = turns.indexOf(aTurn);
    return index;
  }

  public boolean setPlayer(Player aPlayer)
  {
    boolean wasSet = false;
    if (aPlayer == null)
    {
      return wasSet;
    }

    Player existingPlayer = player;
    player = aPlayer;
    if (existingPlayer != null && !existingPlayer.equals(aPlayer))
    {
      existingPlayer.removeSpecificPiece(this);
    }
    player.addSpecificPiece(this);
    wasSet = true;
    return wasSet;
  }

  public boolean setPieceType(PieceType aPieceType)
  {
    boolean wasSet = false;
    if (aPieceType == null)
    {
      return wasSet;
    }

    PieceType existingPieceType = pieceType;
    pieceType = aPieceType;
    if (existingPieceType != null && !existingPieceType.equals(aPieceType))
    {
      existingPieceType.removeSpecificPiece(this);
    }
    pieceType.addSpecificPiece(this);
    wasSet = true;
    return wasSet;
  }

  public boolean setBoard(Board aBoard)
  {
    boolean wasSet = false;
    if (aBoard == null)
    {
      return wasSet;
    }

    Board existingBoard = board;
    board = aBoard;
    if (existingBoard != null && !existingBoard.equals(aBoard))
    {
      existingBoard.removeSpecificPiece(this);
    }
    board.addSpecificPiece(this);
    wasSet = true;
    return wasSet;
  }

  public boolean setSquare(Square aNewSquare)
  {
    boolean wasSet = false;
    if (aNewSquare == null)
    {
      Square existingSquare = square;
      square = null;
      
      if (existingSquare != null && existingSquare.getSpecificPiece() != null)
      {
        existingSquare.setSpecificPiece(null);
      }
      wasSet = true;
      return wasSet;
    }

    Square currentSquare = getSquare();
    if (currentSquare != null && !currentSquare.equals(aNewSquare))
    {
      currentSquare.setSpecificPiece(null);
    }

    square = aNewSquare;
    SpecificPiece existingSpecificPiece = aNewSquare.getSpecificPiece();

    if (!equals(existingSpecificPiece))
    {
      aNewSquare.setSpecificPiece(this);
    }
    wasSet = true;
    return wasSet;
  }

  public static int minimumNumberOfTurns()
  {
    return 0;
  }

  public boolean addTurn(Turn aTurn)
  {
    boolean wasAdded = false;
    if (turns.contains(aTurn)) { return false; }
    turns.add(aTurn);
    if (aTurn.indexOfSpecificPiece(this) != -1)
    {
      wasAdded = true;
    }
    else
    {
      wasAdded = aTurn.addSpecificPiece(this);
      if (!wasAdded)
      {
        turns.remove(aTurn);
      }
    }
    return wasAdded;
  }

  public boolean removeTurn(Turn aTurn)
  {
    boolean wasRemoved = false;
    if (!turns.contains(aTurn))
    {
      return wasRemoved;
    }

    int oldIndex = turns.indexOf(aTurn);
    turns.remove(oldIndex);
    if (aTurn.indexOfSpecificPiece(this) == -1)
    {
      wasRemoved = true;
    }
    else
    {
      wasRemoved = aTurn.removeSpecificPiece(this);
      if (!wasRemoved)
      {
        turns.add(oldIndex,aTurn);
      }
    }
    return wasRemoved;
  }

  public boolean addTurnAt(Turn aTurn, int index)
  {  
    boolean wasAdded = false;
    if(addTurn(aTurn))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfTurns()) { index = numberOfTurns() - 1; }
      turns.remove(aTurn);
      turns.add(index, aTurn);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveTurnAt(Turn aTurn, int index)
  {
    boolean wasAdded = false;
    if(turns.contains(aTurn))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfTurns()) { index = numberOfTurns() - 1; }
      turns.remove(aTurn);
      turns.add(index, aTurn);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addTurnAt(aTurn, index);
    }
    return wasAdded;
  }

  public void delete()
  {
    Player placeholderPlayer = player;
    this.player = null;
    placeholderPlayer.removeSpecificPiece(this);
    PieceType placeholderPieceType = pieceType;
    this.pieceType = null;
    placeholderPieceType.removeSpecificPiece(this);
    Board placeholderBoard = board;
    this.board = null;
    placeholderBoard.removeSpecificPiece(this);
    if (square != null)
    {
      square.setSpecificPiece(null);
    }
    ArrayList<Turn> copyOfTurns = new ArrayList<Turn>(turns);
    turns.clear();
    for(Turn aTurn : copyOfTurns)
    {
      aTurn.removeSpecificPiece(this);
    }
  }

}