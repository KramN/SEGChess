/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.18.0.3190 modeling language!*/



// line 7 "model.ump"
public class Square
{
  @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
  public @interface umplesourcefile{int[] line();String[] file();int[] javaline();int[] length();}

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Square Attributes
  private int xCoord;
  private int yCoord;

  //Square Associations
  private SpecificPiece specificPiece;
  private Board board;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Square(int aXCoord, int aYCoord, Board aBoard)
  {
    xCoord = aXCoord;
    yCoord = aYCoord;
    boolean didAddBoard = setBoard(aBoard);
    if (!didAddBoard)
    {
      throw new RuntimeException("Unable to create square due to board");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setXCoord(int aXCoord)
  {
    boolean wasSet = false;
    xCoord = aXCoord;
    wasSet = true;
    return wasSet;
  }

  public boolean setYCoord(int aYCoord)
  {
    boolean wasSet = false;
    yCoord = aYCoord;
    wasSet = true;
    return wasSet;
  }

  public int getXCoord()
  {
    return xCoord;
  }

  public int getYCoord()
  {
    return yCoord;
  }

  public SpecificPiece getSpecificPiece()
  {
    return specificPiece;
  }

  public Board getBoard()
  {
    return board;
  }

  public boolean setSpecificPiece(SpecificPiece aNewSpecificPiece)
  {
    boolean wasSet = false;
    if (aNewSpecificPiece == null)
    {
      SpecificPiece existingSpecificPiece = specificPiece;
      specificPiece = null;
      
      if (existingSpecificPiece != null && existingSpecificPiece.getSquare() != null)
      {
        existingSpecificPiece.setSquare(null);
      }
      wasSet = true;
      return wasSet;
    }

    SpecificPiece currentSpecificPiece = getSpecificPiece();
    if (currentSpecificPiece != null && !currentSpecificPiece.equals(aNewSpecificPiece))
    {
      currentSpecificPiece.setSquare(null);
    }

    specificPiece = aNewSpecificPiece;
    Square existingSquare = aNewSpecificPiece.getSquare();

    if (!equals(existingSquare))
    {
      aNewSpecificPiece.setSquare(this);
    }
    wasSet = true;
    return wasSet;
  }

  public boolean setBoard(Board aBoard)
  {
    boolean wasSet = false;
    if (aBoard == null)
    {
      return wasSet;
    }

    Board existingBoard = board;
    board = aBoard;
    if (existingBoard != null && !existingBoard.equals(aBoard))
    {
      existingBoard.removeSquare(this);
    }
    board.addSquare(this);
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    if (specificPiece != null)
    {
      specificPiece.setSquare(null);
    }
    Board placeholderBoard = board;
    this.board = null;
    placeholderBoard.removeSquare(this);
  }


  public String toString()
  {
	  String outputString = "";
    return super.toString() + "["+
            "xCoord" + ":" + getXCoord()+ "," +
            "yCoord" + ":" + getYCoord()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "specificPiece = "+(getSpecificPiece()!=null?Integer.toHexString(System.identityHashCode(getSpecificPiece())):"null") + System.getProperties().getProperty("line.separator") +
            "  " + "board = "+(getBoard()!=null?Integer.toHexString(System.identityHashCode(getBoard())):"null")
     + outputString;
  }
}